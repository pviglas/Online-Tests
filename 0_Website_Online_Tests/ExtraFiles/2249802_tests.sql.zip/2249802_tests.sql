-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Φιλοξενητής: 127.0.0.1
-- Χρόνος δημιουργίας: 26 Ιαν 2018 στις 10:08:50
-- Έκδοση διακομιστή: 10.1.28-MariaDB
-- Έκδοση PHP: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `2249802_tests`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `questionmc`
--

CREATE TABLE `questionmc` (
  `id` int(11) NOT NULL,
  `query` varchar(500) DEFAULT NULL,
  `choice1` varchar(100) DEFAULT NULL,
  `choice2` varchar(100) DEFAULT NULL,
  `choice3` varchar(100) DEFAULT NULL,
  `choice4` varchar(100) DEFAULT NULL,
  `monades` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `questionmc`
--

INSERT INTO `questionmc` (`id`, `query`, `choice1`, `choice2`, `choice3`, `choice4`, `monades`) VALUES
(1, ' Which is the break line command <..>?', 'br', 'a', 'hr', 'b', 1),
(2, ' Where do we use LAMP?', 'Linux', 'Windows', 'iOs', 'I dont know!', 2),
(3, ' Whats is apple?', 'A fruit', 'Operating System', 'A company', 'I dont know!', 4),
(4, 'When will you finish uni?', 'In 5 years', 'In 1 year', 'Never.', 'I dont know!', 1),
(5, 'Which of the answers is not programming language?', 'C', 'Java', 'PHP', 'HTML', 3),
(6, 'What is a global array in PHP?', 'A normal array.', 'An array with values that can be seen in the whole program.', 'A normal variable.', 'I dont know!', 2),
(7, 'Another subject.', 'a', 'b', 'c', 'd', 10),
(8, 'Another subjet again!', 'a', 'b', 'c', 'd', 10),
(9, 'Do GET and POST in PHP have any differences?', 'No, they are the same.', 'Yes,POST is safer.', 'Yes,GET is safer.', 'I dont know.', NULL);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `questionmcbelongssub`
--

CREATE TABLE `questionmcbelongssub` (
  `qid` int(11) NOT NULL,
  `subName` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `questionmcbelongssub`
--

INSERT INTO `questionmcbelongssub` (`qid`, `subName`) VALUES
(1, 'www'),
(2, 'www'),
(3, 'www'),
(4, 'www'),
(5, 'www'),
(6, 'www'),
(7, 'C'),
(8, 'C'),
(9, 'www');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `questionmcbelongstest`
--

CREATE TABLE `questionmcbelongstest` (
  `qid` int(11) NOT NULL,
  `testTit` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `questionmcbelongstest`
--

INSERT INTO `questionmcbelongstest` (`qid`, `testTit`) VALUES
(1, 'ready2'),
(1, 'www_ready1'),
(1, 'www_test01'),
(1, 'www_test04'),
(1, 'www_test05'),
(2, 'www_ready1'),
(2, 'www_test01'),
(2, 'www_test05'),
(3, 'ready2'),
(3, 'www_test02'),
(3, 'www_test04'),
(4, 'www_test03'),
(4, 'www_test05'),
(6, 'OneAndOne'),
(6, 'www_test05'),
(9, 'www_easy');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `questionn`
--

CREATE TABLE `questionn` (
  `id` int(11) NOT NULL,
  `query` varchar(500) DEFAULT NULL,
  `monades` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `questionn`
--

INSERT INTO `questionn` (`id`, `query`, `monades`) VALUES
(1, 'Where do we use css ?', 2),
(2, ' Why Linux and not Window?', 5),
(3, 'write a program to calculate the visitors per week of a site', 2),
(4, 'When you should use parent and children programs?', 2),
(5, 'Can you create decent animations with javascript?', 3),
(6, 'The Cookies are usefull or not, and why', 2),
(7, 'What is global variable?', 3),
(8, 'Another subjet oeo!', 10),
(9, 'Another subjet oeo2!', 10),
(10, 'How was your day today?', NULL),
(11, ' Who invented PHP language?\r\n', NULL);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `questionnbelongssub`
--

CREATE TABLE `questionnbelongssub` (
  `qid` int(11) NOT NULL,
  `subName` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `questionnbelongssub`
--

INSERT INTO `questionnbelongssub` (`qid`, `subName`) VALUES
(1, 'www'),
(2, 'www'),
(3, 'www'),
(4, 'www'),
(5, 'www'),
(6, 'www'),
(7, 'www'),
(8, 'C'),
(9, 'C'),
(10, 'www'),
(11, 'www');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `questionnbelongstest`
--

CREATE TABLE `questionnbelongstest` (
  `qid` int(11) NOT NULL,
  `testTit` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `questionnbelongstest`
--

INSERT INTO `questionnbelongstest` (`qid`, `testTit`) VALUES
(1, 'www_test03'),
(1, 'www_test05'),
(2, 'ready2'),
(2, 'www_test03'),
(3, 'www_test04'),
(3, 'www_test05'),
(3, 'www_test06'),
(4, 'www_test04'),
(4, 'www_test06'),
(5, 'OneAndOne'),
(5, 'www_test04'),
(5, 'www_test05'),
(6, 'www_ready1'),
(6, 'www_test05'),
(7, 'www_test05'),
(10, 'ready2'),
(10, 'www_easy'),
(11, 'www_easy2');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `subject`
--

CREATE TABLE `subject` (
  `name` varchar(30) NOT NULL,
  `semester` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `subject`
--

INSERT INTO `subject` (`name`, `semester`) VALUES
('www', 5);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `test`
--

CREATE TABLE `test` (
  `title` varchar(30) NOT NULL,
  `time` double DEFAULT NULL,
  `subName` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `test`
--

INSERT INTO `test` (`title`, `time`, `subName`) VALUES
('www_test01', 1, 'www'),
('www_test02', 2, 'www'),
('www_test03', 2, 'www'),
('www_test05', 3, 'www'),
('www_test04', 2, 'www'),
('www_test06', 2, 'www'),
('OneAndOne', 2, 'www'),
('www_easy', 1, 'www'),
('www_easy2', 1, 'www'),
('www_ready1', 3, 'www'),
('ready2', 2, 'www'),
('testfinal', 1, 'www');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `user`
--

CREATE TABLE `user` (
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(500) NOT NULL,
  `pws` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `gen` varchar(7) NOT NULL,
  `date` date NOT NULL,
  `token` varchar(10) NOT NULL,
  `first_failed_login` time NOT NULL,
  `failed_login_count` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `user`
--

INSERT INTO `user` (`fname`, `lname`, `username`, `pws`, `email`, `gen`, `date`, `token`, `first_failed_login`, `failed_login_count`) VALUES
('root', 'root', 'admin', 'uthadmin3W', 'ontest@uth.com', 'male', '2016-12-01', '', '00:00:00', 0),
('Panos', 'Viglas', 'paviglas', '28p7z0rtxf', 'pan.vig@hotmail.com', 'male', '1996-03-23', '', '00:00:00', 0),
('george', 'papadopolos', 'george', '123georgeEg123', 'g@yahoo.gr', 'male', '1996-12-12', '', '00:00:00', 0),
('teo123', 'teo123n', 'nteo123n', 'nasdasd123123asdAaA', 'teo@hotmail.com', 'male', '1995-05-25', '', '00:00:00', 0);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `useranswersquestionmc`
--

CREATE TABLE `useranswersquestionmc` (
  `username` varchar(50) NOT NULL,
  `qid` int(11) NOT NULL,
  `answer` varchar(500) DEFAULT NULL,
  `grade` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `useranswersquestionmc`
--

INSERT INTO `useranswersquestionmc` (`username`, `qid`, `answer`, `grade`) VALUES
('george', 6, 'I dont know! ', NULL),
('ikelemati', 4, 'In 1 year ', NULL),
('paviglas', 1, 'b ', NULL),
('paviglas', 2, 'I dont know! ', NULL),
('ikelemati', 6, 'An array with values that can be seen in the whole program. ', NULL),
('ikelemati', 2, 'Linux ', NULL),
('ikelemati', 1, 'br ', NULL),
('ikelemati', 3, 'A company ', NULL),
('nkaloritis', 1, 'br ', NULL),
('nkaloritis', 2, 'Linux ', NULL),
('paviglas', 9, 'Yes,POST is safer. ', NULL),
('nkaloritis', 9, 'No, they are the same. ', NULL),
('paviglas', 3, 'A fruit ', NULL),
('ikelemati', 9, 'No, they are the same. ', NULL),
('paviglas', 6, 'An array with values that can be seen in the whole program. ', NULL),
('paviglas', 4, 'Never. ', NULL),
('george', 1, 'b ', NULL),
('george', 2, 'I dont know! ', NULL),
('raf123', 1, 'br ', NULL),
('raf123', 2, 'Linux ', NULL);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `useranswersquestionn`
--

CREATE TABLE `useranswersquestionn` (
  `username` varchar(50) NOT NULL,
  `qid` int(11) NOT NULL,
  `answer` varchar(500) DEFAULT NULL,
  `grade` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `useranswersquestionn`
--

INSERT INTO `useranswersquestionn` (`username`, `qid`, `answer`, `grade`) VALUES
('george', 5, 'one and one', NULL),
('ikelemati', 1, 'i dont know', NULL),
('ikelemati', 2, 'because linux is free', NULL),
('ikelemati', 3, 'Same.', NULL),
('ikelemati', 6, 'Read the above.', NULL),
('paviglas', 10, 'Great!', NULL),
('nkaloritis', 10, 'fg', NULL),
('paviglas', 2, 'cause of free\r\n', NULL),
('ikelemati', 10, 'great , thanks for asking', NULL),
('paviglas', 5, 'no..', NULL),
('paviglas', 1, 'For graphics', NULL),
('george', 6, 'ready', NULL);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `writestest`
--

CREATE TABLE `writestest` (
  `username` varchar(50) NOT NULL,
  `test_title` varchar(30) NOT NULL,
  `finalGrade` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `writestest`
--

INSERT INTO `writestest` (`username`, `test_title`, `finalGrade`) VALUES
('paviglas', 'www_test05', 0),
('george', 'www_test05', 1),
('george', 'OneAndOne', 2),
('ikelemati', 'www_test03', 7),
('paviglas', 'www_test01', 8),
('ikelemati', 'www_test01', 4),
('ikelemati', 'www_test05', 5),
('ikelemati', 'www_test02', 9),
('nkaloritis', 'www_test01', NULL),
('paviglas', 'OneAndOne', 2),
('paviglas', 'www_easy', NULL),
('nkaloritis', 'www_easy', 5),
('paviglas', 'ready2', 0),
('ikelemati', 'www_easy', 0),
('paviglas', 'www_test03', 0),
('george', 'www_ready1', NULL),
('raf123', 'www_test01', 9);

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `questionmc`
--
ALTER TABLE `questionmc`
  ADD PRIMARY KEY (`id`);

--
-- Ευρετήρια για πίνακα `questionmcbelongssub`
--
ALTER TABLE `questionmcbelongssub`
  ADD PRIMARY KEY (`qid`,`subName`),
  ADD KEY `subName` (`subName`);

--
-- Ευρετήρια για πίνακα `questionmcbelongstest`
--
ALTER TABLE `questionmcbelongstest`
  ADD PRIMARY KEY (`qid`,`testTit`),
  ADD KEY `testTit` (`testTit`);

--
-- Ευρετήρια για πίνακα `questionn`
--
ALTER TABLE `questionn`
  ADD PRIMARY KEY (`id`);

--
-- Ευρετήρια για πίνακα `questionnbelongssub`
--
ALTER TABLE `questionnbelongssub`
  ADD PRIMARY KEY (`qid`,`subName`),
  ADD KEY `subName` (`subName`);

--
-- Ευρετήρια για πίνακα `questionnbelongstest`
--
ALTER TABLE `questionnbelongstest`
  ADD PRIMARY KEY (`qid`,`testTit`),
  ADD KEY `testTit` (`testTit`);

--
-- Ευρετήρια για πίνακα `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`name`);

--
-- Ευρετήρια για πίνακα `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`title`);

--
-- Ευρετήρια για πίνακα `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Ευρετήρια για πίνακα `useranswersquestionmc`
--
ALTER TABLE `useranswersquestionmc`
  ADD PRIMARY KEY (`username`,`qid`),
  ADD KEY `qid` (`qid`);

--
-- Ευρετήρια για πίνακα `useranswersquestionn`
--
ALTER TABLE `useranswersquestionn`
  ADD PRIMARY KEY (`username`,`qid`),
  ADD KEY `qid` (`qid`);

--
-- Ευρετήρια για πίνακα `writestest`
--
ALTER TABLE `writestest`
  ADD PRIMARY KEY (`username`,`test_title`),
  ADD KEY `test_title` (`test_title`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `questionmc`
--
ALTER TABLE `questionmc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT για πίνακα `questionn`
--
ALTER TABLE `questionn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
